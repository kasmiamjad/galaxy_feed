

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Preview Imported Data</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(isset($data) && $data->isNotEmpty()): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <!-- Update header based on your Excel columns -->
                    <th>From ID</th>
                    <th>To ID</th>
                    <th>Sender ID</th>
                    <th>Buyer Part ID</th>
                    <th>Description</th>
                    <th>Location</th>
                    <th>Period Start Date</th>
                    <th>Period End Date</th>
                    <th>UOM</th>
                    <th>Order Forecast</th>
                    <th>Forecast Acknowledgement</th>
                    <th>Previous Forecast</th>
                    <th>Forecast Period</th>
                    <th>Compliance Period (months)</th>
                    <th>Compliance Qty on Ground</th>
                    <th>Supplier's On-Hand Stock</th>
                    <th>Supplier's Quality Inspection Stock</th>
                    <th>Supplier's Open POs</th>
                    <th>Supplier's RM On Hand On Order ETA</th>
                    <th>Supplier's Total On-Hand Stock</th>
                    <th>Quantity In-Transit</th>
                    <th>Supplier's On-Hand Under Manufacturing</th>
                    <th>RM Country of Origin</th>
                    <th>PA#</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row[0]); ?></td>
                        <td><?php echo e($row[1]); ?></td>
                        <td><?php echo e($row[2]); ?></td>
                        <td><?php echo e($row[3]); ?></td>
                        <td><?php echo e($row[4]); ?></td>
                        <td><?php echo e($row[5]); ?></td>
                        <td>
                            <?php
                                $startDate = $row[6];
                                try {
                                    $parsedStartDate = \Carbon\Carbon::parse($startDate)->format('Y-m-d');
                                    echo $parsedStartDate;
                                } catch (\Exception $e) {
                                    echo 'Invalid Date';
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $endDate = $row[7];
                                try {
                                    $parsedEndDate = \Carbon\Carbon::parse($endDate)->format('Y-m-d');
                                    echo $parsedEndDate;
                                } catch (\Exception $e) {
                                    echo 'Invalid Date';
                                }
                            ?>
                        </td>
                        <td><?php echo e($row[8]); ?></td>
                        <td><?php echo e($row[9]); ?></td>
                        <td><?php echo e($row[10]); ?></td>
                        <td><?php echo e($row[11]); ?></td>
                        <td><?php echo e($row[12]); ?></td>
                        <td><?php echo e($row[13]); ?></td>
                        <td><?php echo e($row[14]); ?></td>
                        <td><?php echo e($row[15]); ?></td>
                        <td><?php echo e($row[16]); ?></td>
                        <td><?php echo e($row[17]); ?></td>
                        <td><?php echo e($row[18]); ?></td>
                        <td><?php echo e($row[19]); ?></td>
                        <td><?php echo e($row[20]); ?></td>
                        <td><?php echo e($row[21]); ?></td>
                        <td><?php echo e($row[22]); ?></td>
                        <td><?php echo e($row[23]); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination Links -->
        <div class="pagination">
            <?php echo e($data->links()); ?>

        </div>

        <!-- Form to confirm import -->
        <?php if(isset($filePath)): ?>
            <form action="<?php echo e(route('forecasts.confirm')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="file_path" value="<?php echo e($filePath); ?>">
                <button type="submit" class="btn btn-primary">Confirm Import</button>
            </form>
        <?php endif; ?>
    <?php else: ?>
        <p>No data to display.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ali\galaxy_feed\resources\views/forecasts/preview.blade.php ENDPATH**/ ?>