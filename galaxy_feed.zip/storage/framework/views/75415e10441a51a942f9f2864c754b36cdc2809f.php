

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Forecast</h1>

    <form action="<?php echo e(route('forecasts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="field1">Field1</label>
            <input type="text" name="field1" class="form-control" id="field1" required>
        </div>
        <div class="form-group">
            <label for="field2">Field2</label>
            <input type="text" name="field2" class="form-control" id="field2" required>
        </div>
        <!-- Add more fields as necessary -->
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ali\galaxy_feed\resources\views/forecasts/create.blade.php ENDPATH**/ ?>